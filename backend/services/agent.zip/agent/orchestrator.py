import json
import re

from sqlalchemy.orm import Session

from services.ai.ai_services import AIService
from crud.agent_audit import create_agent_audit_log
from services.agent.tool_registry import get_tool
from services.agent.tool_schemas import get_tool_schemas


class AgentOrchestrator:

    MAX_STEPS = 5

    # ============================================================
    # TOOL PERMISSION GROUPS
    # ============================================================

    # Tools that are safe for applicants.
    #
    # Applicants have READ-ONLY access through the agent.
    #
    # IMPORTANT:
    # No write/action tools should be placed here.
    APPLICANT_ALLOWED_TOOLS = {
        "search_institutional_knowledge",

        "get_student_profile",
        "get_admission_status",

        "get_required_documents",
        "get_document_status",
        "verify_documents",
        "get_fee_status",

        "get_onboarding_tasks",
        "get_onboarding_summary",
        "get_next_onboarding_action",
        "create_ticket",
        "get_my_tickets",
        "get_ticket_status",
    }

    # ============================================================
    # REGISTERED STUDENT TOOLS
    # ============================================================

    # Tools available to a registered student.
    #
    # student_id and organization_id are ALWAYS injected by the
    # server and are never controlled by the LLM.
    STUDENT_ALLOWED_TOOLS = {
        "search_institutional_knowledge",

        "get_student_profile",
        "get_admission_status",

        "get_required_documents",
        "get_document_status",
        "verify_documents",
        "get_fee_status",

        "get_onboarding_tasks",
        "get_onboarding_summary",
        "get_next_onboarding_action",

        "complete_onboarding_task",
        "complete_academic_registration",
        "complete_library_registration",
        "complete_id_card_registration",
        "create_ticket",
        "get_my_tickets",
        "get_ticket_status",
    }

    # ============================================================
    # INITIALIZATION
    # ============================================================

    def __init__(self):

        self.ai_service = AIService()

        self.tool_schemas = get_tool_schemas()

    # ============================================================
    # ALLOWED TOOLS
    # ============================================================

    def _get_allowed_tools(
        self,
        is_applicant: bool,
    ):
        """
        Return the tools the authenticated identity is allowed
        to use.

        Permission is determined by the server.

        The LLM cannot:
            - choose its permission level
            - upgrade applicant -> student
            - choose another student
            - choose another organization
        """

        if is_applicant:

            return self.APPLICANT_ALLOWED_TOOLS

        return self.STUDENT_ALLOWED_TOOLS

    # ============================================================
    # FILTER TOOL SCHEMAS
    # ============================================================

    def _get_allowed_tool_schemas(
        self,
        is_applicant: bool,
    ):
        """
        Return only schemas for tools available to the current
        authenticated identity.

        This prevents the LLM from being instructed about tools
        that the identity is not allowed to use.
        """

        allowed_tools = (
            self._get_allowed_tools(
                is_applicant=is_applicant
            )
        )

        return [
            schema
            for schema in self.tool_schemas
            if schema.get("name") in allowed_tools
        ]

    # ============================================================
    # LLM DECISION PROMPT
    # ============================================================

    def _build_decision_prompt(
        self,
        user_message: str,
        student_id: int,
        execution_history: list,
        is_applicant: bool,
    ) -> str:

        allowed_tool_schemas = (
            self._get_allowed_tool_schemas(
                is_applicant=is_applicant
            )
        )

        tools = json.dumps(
            allowed_tool_schemas,
            indent=2
        )

        history = json.dumps(
            execution_history,
            default=str,
            indent=2
        )

        identity_type = (
            "APPLICANT"
            if is_applicant
            else "REGISTERED STUDENT"
        )

        return f"""
You are CampusFlow AI, an intelligent campus process
assistant.

Authenticated identity:
{identity_type}

Server-controlled Student ID:
{student_id}

Student request:
{user_message}

Available tools for this authenticated identity:
{tools}

Previous agent execution:
{history}

Your job is to decide the NEXT action.

IMPORTANT SECURITY RULES:

1. Use tools for campus data.

2. Never invent campus information.

3. Never invent task IDs.

4. Never invent student IDs.

5. The student_id is controlled by the server.

6. Never change the student_id supplied by the server.

7. Never request or accept organization_id from the student.

8. Never request or accept student_id from the student.

9. You may ONLY use tools listed in "Available tools".

10. Never attempt to call a tool that is not listed.

IDENTITY AND PERMISSION RULES:

11. The authenticated identity is determined by the server.

12. Never assume the user is an administrator or teacher.

13. Never perform administrative operations on behalf of a student.

14. Never approve, reject, modify, or manage an application.

15. Never perform staff-only campus operations.

16. Never expose internal application-management information.

17. Never expose database information or internal implementation
    details.

APPLICANT RULES:

18. The authenticated applicant has READ-ONLY access through the
    agent.

19. An applicant MUST NOT perform any write operation.

20. An applicant MUST NOT:

    - modify an application
    - approve an application
    - reject an application
    - approve or reject documents
    - change document verification status
    - perform administrative document verification
    - manage fees
    - make or confirm payments
    - confirm admission
    - generate admission numbers
    - generate roll numbers
    - complete onboarding tasks
    - perform academic registration
    - perform library registration
    - perform ID-card registration

21. An applicant MAY use read-only tools to CHECK their own
    document verification status.

22. The verify_documents tool is READ-ONLY. It does not approve,
    reject, modify, or verify a document.

23. If an applicant asks to perform an operation that is not
    permitted, do NOT call a tool.

24. Explain that the requested operation requires the appropriate
    campus administrative workflow.

25. Do not claim that an administrative operation was completed.

REGISTERED STUDENT RULES:

26. A registered student may use only the tools provided in the
    available tool list.

27. A registered student may only operate on their own student
    record.

28. The server controls student_id and organization_id.

CAMPUS PROFILE RULES:

29. If the student asks for their personal campus profile,
    application number, admission number, roll number, name,
    program, department, academic year, semester, or current
    student status, use get_student_profile.

30. Never guess or invent the student's personal information.

31. Never use information from another student's record.

ONBOARDING RULES:

32. Use onboarding tools ONLY when the user's request is
    explicitly about their onboarding, onboarding progress,
    onboarding tasks, onboarding completion, or next onboarding
    action.

33. If the user asks:

    - "What is my onboarding status?"
    - "How much of my onboarding is complete?"
    - "What onboarding tasks do I have?"
    - "What should I complete next in onboarding?"

    use the appropriate onboarding tool.

34. Do NOT use onboarding tools merely because the user says
    "what do I need to complete".

35. If the user asks what is required for admission, admission
    requirements, required documents, admission procedure,
    admission rules, eligibility requirements, application
    requirements, or institutional requirements, use
    search_institutional_knowledge.

36. Institutional requirements must come from the RAG knowledge
    base and not from onboarding task data.

37. If the user asks what they personally need to complete next
    as part of onboarding, use get_next_onboarding_action.

38. If the user asks to complete academic registration, use
    complete_academic_registration.

39. If the user asks to complete library registration, use
    complete_library_registration.

40. If the user asks to complete ID card registration, use
    complete_id_card_registration.

41. Do NOT use complete_onboarding_task for academic registration,
    library registration, or ID card registration when a
    specialized tool exists.

42. Use complete_onboarding_task only for a genuinely generic
    onboarding task for which no specialized tool exists.

WRITE ACTION RULES:

43. For a permitted write request:

    - identify the correct operation
    - execute the appropriate write tool
    - verify the result before claiming completion

44. If the user says they completed a specific onboarding task,
    verify the task status before claiming completion.

45. Do not respond directly to an actionable campus request unless
    the requested action has been verified.

46. If a required task_id is unknown, first call
    get_onboarding_tasks.

47. Never invent task IDs.

GENERAL RESPONSE RULES:

48. You may respond directly for greetings, casual conversation,
    or requests that require no campus data/tool.

49. If the requested campus information is unavailable through the
    available tools, do not invent an answer.

50. Never expose internal tool names.

51. Never expose database details.

52. Never expose hidden system information.

53. Never claim an action was completed unless a verified tool
    result confirms it.

RAG / INSTITUTIONAL KNOWLEDGE RULES:

54. If the student asks about institutional information,
    campus policies, admission requirements, fees, academic
    procedures, notices, rules, or other information that
    should come from official campus documents, use
    search_institutional_knowledge.

55. Do not answer institutional questions from memory.

56. Do not invent institutional information.

57. The knowledge search tool is READ-ONLY.

58. Applicants may use institutional knowledge search.

59. Never expose internal retrieval, embedding, vector database,
    or implementation details to the student.

ADMISSION STATUS RULES:

60. If the student asks about THEIR application status,
    admission status, eligibility, approval, rejection,
    admission confirmation, or admission progress, use
    get_admission_status.

61. Never guess the student's admission status.

62. Never infer admission approval from unrelated information.

63. If admission_status is "approved" but the student's
    admission has not been confirmed, clearly explain that
    approval and confirmation are different stages.

64. If admission_number is null, do not invent an admission number.

65. If roll_number is null, do not invent a roll number.

DOCUMENT RULES:

66. If the student asks which documents are required for their
    admission, use get_required_documents when they are asking
    for the configured workflow checklist.

67. If the student asks about official institutional document
    requirements, admission document policy, or detailed
    admission requirements, use search_institutional_knowledge.

68. If the student asks which documents they personally submitted
    or which documents are missing, use get_document_status.

69. If the student asks whether their documents have been verified,
    use verify_documents.

70. verify_documents is READ-ONLY. It must never be described
    as changing, approving, or rejecting a document.

71. Never claim a document is verified unless the tool result
    says its verification_status is "verified".

72. If a document is rejected or review_required, explain that
    staff action may be required.

73. Never confuse:

    - institutional document requirements
      with
      personal submitted-document status

    - personal document status
      with
      document verification

    - document verification status
      with
      admission approval

FEE RULES:

74. If the student asks about THEIR fees, payment status,
    pending fees, mandatory fees, payment reference, or whether
    they have paid a fee, use get_fee_status.

75. If the student asks about general institutional fee rules,
    fee structure, fee policy, refunds, or official fee
    requirements, use search_institutional_knowledge.

76. Never invent fee amounts or payment status.

77. Treat the fee tool result as the source of truth for the
    student's current fee status.

78. Do not claim that a fee is paid unless its status is "paid".

79. Do not claim that a fee is mandatory unless the tool result
    marks it as mandatory.

80. Do not perform or claim to perform a payment through the
    student agent. Payment actions require the existing campus
    payment workflow.

TOOL ARGUMENT RULES:

81. Do NOT provide student_id in tool arguments.

82. Do NOT provide organization_id in tool arguments.

83. These values are automatically injected by the server.

84. For get_student_profile, no arguments are required.

85. For get_admission_status, no arguments are required.

86. For get_required_documents, no arguments are required.

87. For get_document_status, no arguments are required.

88. For verify_documents, no arguments are required.

89. For get_fee_status, no arguments are required.

90. For get_onboarding_tasks, no arguments are required.

91. For get_onboarding_summary, no arguments are required.

92. For get_next_onboarding_action, no arguments are required.

93. For complete_academic_registration, no arguments are required.

94. For complete_library_registration, no arguments are required.

95. For complete_id_card_registration, no arguments are required.

96. complete_onboarding_task requires task_id.

97. search_institutional_knowledge requires question.

MULTI-TOOL REASONING RULES:

98. A single request may require multiple tools.

99. When multiple tools are needed, execute only the tools that
    provide information necessary to answer the user's request.

100. Do not call unrelated tools.

101. For example:

     "What documents are required and which ones have I submitted?"

     should use:

         search_institutional_knowledge
         get_document_status

102. For example:

     "What is my admission status and fee status?"

     should use:

         get_admission_status
         get_fee_status

103. For example:

     "What documents are required and what should I complete
      next in onboarding?"

     should use:

         search_institutional_knowledge
         get_next_onboarding_action

104. Avoid unnecessary tool calls because every tool call should
     have a clear purpose related to the user's request.

DECISION PRIORITY RULES:

105. Prefer PERSONAL campus data tools when the user asks about
     their own current status.

106. Prefer RAG when the user asks about official institutional
     information, policies, requirements, procedures, or rules.

107. Prefer document status tools when the user asks about their
     own submitted or verified documents.

108. Prefer fee status when the user asks about their own current
     fees or payments.

109. Prefer onboarding tools when the user explicitly asks about
     onboarding progress or onboarding actions.

110. If a request contains both institutional information and
     personal campus information, use the appropriate tools for
     both rather than answering either part from memory.

TICKET / COMPLAINT RULES:

1. Use get_my_tickets when the student asks about their complaints,
   support requests, tickets, or previous issues.

2. Use get_ticket_status when the student provides a specific
   ticket number and asks for its status or details.

3. Use create_ticket when the student explicitly reports an issue
   that requires campus staff attention.

4. Do not create a ticket merely because the student asks a normal
   informational question.

5. For a fee issue, first use get_fee_status when the student's
   current fee record is relevant. If the result indicates a
   discrepancy or unresolved issue and the student wants help,
   create a ticket.

6. For document issues, first check document status when appropriate.
   Create a ticket when the student explicitly wants staff assistance
   or the issue requires human intervention.

7. Applicants and students may create and view their own tickets only.

8. Never allow the LLM to provide or control student_id or
   organization_id. These values are injected by the server.

9. Ticket status, assignment, resolution, and escalation are
   staff-controlled operations. The student agent must never modify them.

10. Creating a ticket is an authorized student action. Do not invent
    a ticket number; use the number returned by create_ticket.
    
Return ONLY valid JSON.

For a tool call:

{{
    "action": "tool_call",
    "tool_name": "tool name",
    "arguments": {{
        "argument": "value"
    }}
}}

For a final response:

{{
    "action": "respond",
    "message": "response"
}}

JSON ONLY.
"""

    # ============================================================
    # JSON PARSER
    # ============================================================

    def _extract_json(
        self,
        response: str,
    ):

        response = response.strip()

        response = re.sub(
            r"```json\s*",
            "",
            response,
            flags=re.IGNORECASE
        )

        response = re.sub(
            r"```\s*$",
            "",
            response
        )

        try:

            return json.loads(
                response
            )

        except json.JSONDecodeError:

            match = re.search(
                r"\{.*\}",
                response,
                re.DOTALL
            )

            if not match:

                raise ValueError(
                    "LLM did not return valid JSON."
                )

            return json.loads(
                match.group(0)
            )

    # ============================================================
    # TOOL VALIDATION
    # ============================================================

    def _validate_tool(
        self,
        tool_name: str,
        is_applicant: bool,
    ):

        tool = get_tool(
            tool_name
        )

        if tool is None:

            raise ValueError(
                f"Unknown agent tool: {tool_name}"
            )

        allowed_tools = (
            self._get_allowed_tools(
                is_applicant=is_applicant
            )
        )

        # --------------------------------------------------------
        # SERVER-SIDE AUTHORIZATION
        # --------------------------------------------------------

        if tool_name not in allowed_tools:

            if is_applicant:

                raise PermissionError(
                    "This operation is not available to applicants. "
                    "Please use the appropriate campus administrative "
                    "workflow."
                )

            raise PermissionError(
                "This operation is not available to registered "
                "students."
            )

        return tool

    # ============================================================
    # TOOL EXECUTION
    # ============================================================

    def _execute_tool(
        self,
        db: Session,
        tool_name: str,
        arguments: dict,
        student_id: int,
        organization_id: int,
        is_applicant: bool,
    ):
    

        tool = self._validate_tool(
            tool_name=tool_name,
            is_applicant=is_applicant,
        )

        # --------------------------------------------------------
        # SERVER-CONTROLLED CONTEXT
        # --------------------------------------------------------
        #
        # The LLM never controls these values.
        #

        arguments = dict(arguments)

        # --------------------------------------------------------
        # Prevent LLM from overriding server identity.
        # --------------------------------------------------------

        arguments.pop("student_id", None)
        arguments.pop("organization_id", None)

        # --------------------------------------------------------
        # Inject trusted server context.
        # --------------------------------------------------------

        arguments["student_id"] = student_id
        arguments["organization_id"] = organization_id

        # --------------------------------------------------------
        # Determine action type
        # --------------------------------------------------------

        WRITE_TOOLS = {
            "create_ticket",
            "complete_onboarding_task",
            "complete_academic_registration",
            "complete_library_registration",
            "complete_id_card_registration",
            "initialize_onboarding",
        }

        action_type = (
            "write"
            if tool_name in WRITE_TOOLS
            else "read"
        )

        # --------------------------------------------------------
        # Prepare safe audit input
        # --------------------------------------------------------

        audit_arguments = {
            key: value
            for key, value in arguments.items()
            if key not in {
                "student_id",
                "organization_id",
                "password",
                "password_hash",
                "applicant_password_hash",
            }
        }

        input_summary = json.dumps(
            audit_arguments,
            default=str,
        )

        # --------------------------------------------------------
        # Execute tool
        # --------------------------------------------------------

        try:

            result = tool(
                db=db,
                **arguments,
            )

            # ----------------------------------------------------
            # Successful tool execution
            # ----------------------------------------------------

            output_summary = json.dumps(
                result,
                default=str,
            )

            create_agent_audit_log(
                db=db,
                organization_id=organization_id,
                student_id=student_id,
                tool_name=tool_name,
                action_type=action_type,
                status="success",
                input_summary=input_summary,
                output_summary=output_summary,
            )

            # Make sure audit log is persisted.
            db.commit()

            return result

        except Exception as exc:

            # ----------------------------------------------------
            # Tool failed
            # ----------------------------------------------------

            db.rollback()

            create_agent_audit_log(
                db=db,
                organization_id=organization_id,
                student_id=student_id,
                tool_name=tool_name,
                action_type=action_type,
                status="failed",
                input_summary=input_summary,
                error_message=str(exc),
            )

            db.commit()

            raise
    # ============================================================
    # FINAL RESPONSE
    # ============================================================

    def _build_final_response_prompt(
        self,
        user_message: str,
        execution_history: list,
    ):

        history = json.dumps(
            execution_history,
            default=str,
            indent=2
        )

        return f"""
You are CampusFlow AI.

Student request:

{user_message}

Verified agent execution history:

{history}

Generate the final response to the student.

Rules:

1. Use only verified tool results.

2. Do not invent information.

3. Do not mention internal tool names.

4. Do not mention databases.

5. Do not mention implementation details.

6. Clearly explain what happened.

7. If an action was completed, say so.

8. If an action was already completed, explain that.

9. If the operation failed, clearly explain the reason.

10. If another onboarding task remains, optionally mention it.

11. Keep the response concise and natural.

12. Never expose student_id or organization_id.

13. Never expose passwords, password hashes, tokens, or
    internal authentication information.

14. If the response is based on institutional knowledge,
    present the information as official campus guidance.

15. If citations are present in the tool result, preserve the
    grounding of the answer without exposing internal retrieval
    or vector database details.

16. Do not claim that a document has been approved or rejected
    unless the verified tool result explicitly states that status.

17. Do not claim that a fee has been paid unless the verified
    fee result explicitly states that it is paid.

18. Clearly distinguish:
    - admission approval
    - admission confirmation
    - document verification
    - fee payment
    - onboarding completion

Return plain text only.
"""

    # ============================================================
    # MAIN AGENT LOOP
    # ============================================================

    def run(
        self,
        db: Session,
        student_id: int,
        organization_id: int,
        user_message: str,
        is_applicant: bool = False,
    ):

        execution_history = []

        for step in range(
            self.MAX_STEPS
        ):

            decision_prompt = (
                self._build_decision_prompt(
                    user_message=user_message,
                    student_id=student_id,
                    execution_history=execution_history,
                    is_applicant=is_applicant,
                )
            )

            decision_response = (
                self.ai_service.generate_answer(
                    decision_prompt
                )
            )

            decision = self._extract_json(
                decision_response
            )

            # ====================================================
            # FINAL RESPONSE
            # ====================================================

            if decision.get(
                "action"
            ) == "respond":

                # ------------------------------------------------
                # TOOL EXECUTION EXISTED
                # ------------------------------------------------

                if execution_history:

                    final_prompt = (
                        self._build_final_response_prompt(
                            user_message=user_message,
                            execution_history=execution_history
                        )
                    )

                    final_response = (
                        self.ai_service.generate_answer(
                            final_prompt
                        )
                    )

                    return {
                        "type": "agent_response",
                        "steps": execution_history,
                        "message": final_response
                    }

                # ------------------------------------------------
                # DIRECT RESPONSE
                # ------------------------------------------------

                return {
                    "type": "response",
                    "message": decision.get(
                        "message",
                        ""
                    )
                }

            # ====================================================
            # TOOL CALL
            # ====================================================

            if decision.get(
                "action"
            ) != "tool_call":

                raise ValueError(
                    "Invalid agent action."
                )

            tool_name = decision.get(
                "tool_name"
            )

            arguments = decision.get(
                "arguments",
                {}
            )

            if not isinstance(
                arguments,
                dict
            ):

                raise ValueError(
                    "Tool arguments must be an object."
                )

            # ====================================================
            # EXECUTE AUTHORIZED TOOL
            # ====================================================

            tool_result = (
                self._execute_tool(
                    db=db,
                    tool_name=tool_name,
                    arguments=arguments,
                    student_id=student_id,
                    organization_id=organization_id,
                    is_applicant=is_applicant,
                )
            )

            # ====================================================
            # SAVE VERIFIED EXECUTION
            # ====================================================

            execution_history.append(
                {
                    "step": step + 1,
                    "tool": tool_name,
                    "arguments": arguments,
                    "result": tool_result
                }
            )

        raise RuntimeError(
            "Agent reached maximum execution steps."
        )