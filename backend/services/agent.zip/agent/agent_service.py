from sqlalchemy.orm import Session

from models.student import Student
from schemas.agent import AgentChatRequest

from services.agent.orchestrator import AgentOrchestrator


def process_agent_message(
    db: Session,
    request: AgentChatRequest,
    student: Student,
):
    """
    Process a CampusFlow AI Agent request.

    The authenticated Student object is resolved completely
    server-side.

    Authentication states:

        Applicant:
            student.user_id is NULL

        Registered Student:
            student.user_id is NOT NULL

    The LLM never receives permission to choose:

        - student_id
        - organization_id
        - authentication state
        - role
    """

    # ============================================================
    # DETERMINE AUTHENTICATION STATE
    # ============================================================

    is_applicant = student.user_id is None

    # ============================================================
    # CREATE AGENT
    # ============================================================

    agent = AgentOrchestrator()

    # ============================================================
    # RUN AGENT
    # ============================================================

    return agent.run(
        db=db,
        student_id=student.id,
        organization_id=student.organization_id,
        user_message=request.message,

        # Server-derived permission context.
        #
        # The LLM cannot change this value.
        is_applicant=is_applicant,
    )